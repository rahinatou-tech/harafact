<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ConfigRecurrence;
use App\Models\Facture;
use Illuminate\Http\Request;

class RecurrenceController extends Controller
{
    public function index(Request $request)
    {
        $eid = auth()->user()->entreprise_id;

        $query = ConfigRecurrence::with('client')
            ->where('entreprise_id', $eid);

        if ($request->filled('statut')) {
            $query->where('statut', $request->statut);
        }

        $recurrences = $query->orderByDesc('created_at')->paginate(20);

        return response()->json([
            'data' => $recurrences->items(),
            'meta' => [
                'current_page' => $recurrences->currentPage(),
                'last_page'    => $recurrences->lastPage(),
                'total'        => $recurrences->total(),
            ],
            'stats' => [
                'actives'   => ConfigRecurrence::where('entreprise_id', $eid)->where('statut', 'actif')->count(),
                'pausees'   => ConfigRecurrence::where('entreprise_id', $eid)->where('statut', 'pause')->count(),
                'terminees' => ConfigRecurrence::where('entreprise_id', $eid)->where('statut', 'termine')->count(),
            ],
        ]);
    }

    public function store(Request $request)
    {
        $eid = auth()->user()->entreprise_id;

        $data = $request->validate([
            'client_id'        => 'required|exists:clients,id',
            'nom'              => 'required|string|max:200',
            'frequence'        => 'required|in:quotidienne,hebdomadaire,mensuelle,trimestrielle,semestrielle,annuelle',
            'intervalle'       => 'integer|min:1|max:12',
            'date_debut'       => 'required|date',
            'date_fin'         => 'nullable|date|after:date_debut',
            'max_occurrences'  => 'nullable|integer|min:1',
            'jour_du_mois'     => 'nullable|integer|min:1|max:28',
            'envoi_auto'       => 'boolean',
            'devise'           => 'required|string|size:3',
            // Lignes modèles (optionnel - mémorisées sur la config)
            'lignes_modele'    => 'nullable|array',
        ]);

        $config = ConfigRecurrence::create([
            'entreprise_id'          => $eid,
            'client_id'              => $data['client_id'],
            'nom'                    => $data['nom'],
            'frequence'              => $data['frequence'],
            'intervalle'             => $data['intervalle'] ?? 1,
            'date_debut'             => $data['date_debut'],
            'date_fin'               => $data['date_fin'] ?? null,
            'max_occurrences'        => $data['max_occurrences'] ?? null,
            'jour_du_mois'           => $data['jour_du_mois'] ?? null,
            'envoi_auto'             => $data['envoi_auto'] ?? false,
            'devise'                 => $data['devise'],
            'statut'                 => 'actif',
            'prochaine_generation_le'=> $data['date_debut'],
            'total_genere'           => 0,
            'cree_par'               => auth()->id(),
        ]);

        return response()->json($config->load('client'), 201);
    }

    public function show(int $id)
    {
        $config = ConfigRecurrence::with('client')
            ->where('entreprise_id', auth()->user()->entreprise_id)
            ->findOrFail($id);

        return response()->json($config);
    }

    public function update(Request $request, int $id)
    {
        $config = ConfigRecurrence::where('entreprise_id', auth()->user()->entreprise_id)->findOrFail($id);

        $data = $request->validate([
            'nom'             => 'string|max:200',
            'date_fin'        => 'nullable|date',
            'max_occurrences' => 'nullable|integer|min:1',
            'envoi_auto'      => 'boolean',
            'jour_du_mois'    => 'nullable|integer|min:1|max:28',
        ]);

        $config->update($data);
        return response()->json($config->fresh()->load('client'));
    }

    public function destroy(int $id)
    {
        $config = ConfigRecurrence::where('entreprise_id', auth()->user()->entreprise_id)->findOrFail($id);

        if ($config->factures()->count() > 0) {
            return response()->json(['message' => 'Impossible de supprimer une récurrence ayant des factures générées.'], 422);
        }

        $config->delete();
        return response()->json(['message' => 'Récurrence supprimée.']);
    }

    public function pause(int $id)
    {
        $config = ConfigRecurrence::where('entreprise_id', auth()->user()->entreprise_id)->findOrFail($id);
        $config->update(['statut' => 'pause']);
        return response()->json(['message' => 'Récurrence mise en pause.', 'config' => $config->fresh()]);
    }

    public function reprendre(int $id)
    {
        $config = ConfigRecurrence::where('entreprise_id', auth()->user()->entreprise_id)->findOrFail($id);
        $config->update(['statut' => 'actif']);
        return response()->json(['message' => 'Récurrence relancée.', 'config' => $config->fresh()]);
    }

    public function factures(int $id)
    {
        $config = ConfigRecurrence::where('entreprise_id', auth()->user()->entreprise_id)->findOrFail($id);

        $factures = Facture::with('client')
            ->where('config_recurrence_id', $config->id)
            ->orderByDesc('date_emission')
            ->get();

        return response()->json($factures);
    }
}